Language Settings
1. After uploading has finished, at the Administration area from the Dashboard menu select
"System > Localisation > Languages". Click the "Add New" button, fill in the following
information at the form and press "Save".
Language Name: Tiếng Việt
Code:vi-vn
Locale:vi_VN.UTF-8,vi_VN,vi-vn,vietnamese
Status:Enabled
Sort Order:0
2. From the Dashboard menu select "System > Settings" and click "Edit" at the Default store.
At the edit settings page, select "Local" tab and in the "Language" and "Administration
Language" options, select "vietnamese" and click "Save". Enjoy your new translation !